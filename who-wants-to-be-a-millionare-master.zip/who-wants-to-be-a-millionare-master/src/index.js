const questions = [
  {
    q: "Evrenin ana maddesi nedir sorusunu soran ünlü filozof kimdir?",
    o: ["Platon", "Aristotales", "Thales", "Pisagor"],
    a: 2,
    level: 1, // Seviye 1
  },
  {
    q: "İlk filozof kelimesini kullanan kişi kimdir?",
    o: ["Thales", "Pisagor", "Farabi", "Efesli Herakleitos"],
    a: 1,
    level: 1, // Seviye 1
  },
  {
    q: "Tüm erkekler zekidir ifadesinin çelişiği nedir?",
    o: ["Bazı erkekler zeki değildir.", "Bütün erkekler akıllıdır.", "Hiçbir erkek zeki değildir.", "Erkeklerin hepsi aynı derecede zekidir."],
    a: 0,
    level: 2, // Seviye 2
  },
  {
    q: "Felsefenin en temel sorusu nedir?",
    o: ["Varlık Nedir?", "Ahlak Nedir?", "Bilgi Nedir?", "İnsan Nedir"],
    a: 0,
    level: 1, // Seviye 2
  },
  {
    q: "Özel verilerden genel sonuç çıkarmaya ne denir?",
    o: ["Çıkarım", "Kıyas", "Tümevarım", "Tümdengelim"],
    a: 2,
    level: 3, // Seviye 3
  },
  {
    q: "Aşağıdakilerden hangisi felsefi soru değildir?",
    o: ["Gerçegin bilgisine ulaşmak mümkün müdür?", "Varlığın mahiyeti nedir?", "Benim özgürlüğüm başkasının köleliği midir?", "Sesin kaynakları nelerdir?"],
    a: 3,
    level: 3, // Seviye 3
  },
  {
    q: "Philosophia ne demektir?",
    o: ["Filozof Sevgisi", "Felsefe Sevgisi", "Bilgelik sevgisi", "Sevgi Bilgisi"],
    a: 2,
    level: 2, // Seviye 4
  },
  {
    q: "Felsefede zihnin kendi üzerine dönme hareketine ne denir?",
    o: ["İntrospeksiyon", "Düşünce", "Bilinç", "Refleksif Olma"],
    a: 3,
    level: 3, // Seviye 4
  },
  {
    q: "Aşağıdakilerden hangisi gerçek varlıktır?",
    o: ["Tanrıça heykeli", "Superman", "Adalet", "Üçgen"],
    a: 0,
    level: 3, // Seviye 5
  },
  {
    q: "Bütün canlılar nefes alır ifadesini tikel önermenin olumsuzunu yapacak şekilde düzeltiniz",
    o: [
      "Bazı Canlılar Nefes Almaz.",
      "Canlılar Nefes Alır.",
      "Bütün Canlılar Nefes Almaz",
      "Bazı Canlılar Nefes Alır.",
    ],
    a: 0,
    level: 5, // Seviye 5
  },
  {
    q: "Etik kelimesi ne anlama gelir?",
    o: ["Bilgi", "Ahlak", "Fizik", "Matematik"],
    a: 1,
    level: 4, // Seviye 6
  },
];

// Soruları seviyeye göre sıralama
export const questionAndAnswers = questions.sort((a, b) => a.level - b.level);
