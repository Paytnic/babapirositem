import React from "react";
import "./Question.css";

function Question({ question, options, onSelect }) {
  return (
    <div className="questions-and-answers__item">
      <div className="questions-and-answers__header">
        <div className="questions-and-answers__title">
          <p>{question}</p>
        </div>
      </div>

      <div className="questions-and-answers__content">
        {options.map((option, index) => (
          <div key={index} className="option-container">
            <label className="option-button">
              <input
                type="radio"
                value={option}
                name={question}
                onClick={() => onSelect(option)}
                className="option-input"
              />
              {String.fromCharCode(65 + index)}. {option} {/* A, B, C, D olarak göster */}
            </label>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Question;