import { useState, useEffect } from "react";
import { questionAndAnswers } from ".";
import Question from "./components/Question/Question";
import "./App.css"; // CSS dosyanızı eklemeyi unutmayın

function App() {
  const [score, setScore] = useState(0);
  const [questionIndex, setQuestionIndex] = useState(0);
  const [completed, setCompleted] = useState(false);
  const [gameOver, setGameOver] = useState(false);
  const [fiftyFiftyUsed, setFiftyFiftyUsed] = useState(false);
  const [lifelineCount, setLifelineCount] = useState(2); // Hoca'ya Sorma joker hakkı için
  const [lifelineUsed, setLifelineUsed] = useState(false); // Hoca'ya sorma butonunun kullanılıp kullanılmadığını takip etmek için

  const totalScore = (score / questionAndAnswers.length) * 100;
  const prizeAmounts = [1000, 5000, 10000, 25000, 50000, 75000, 100000, 250000, 500000, 750000, 1000000];

  const restart = () => {
    setScore(0);
    setQuestionIndex(0);
    setCompleted(false);
    setGameOver(false);
    setFiftyFiftyUsed(false);
    setLifelineCount(2); // Joker hakkını sıfırla
    setLifelineUsed(false); // Hoca'ya sorma hakkını sıfırla
    questionAndAnswers.sort(() => Math.random() - 0.5);
  };

  const handleSelect = (e) => {
    if (e === questionAndAnswers[questionIndex].o[questionAndAnswers[questionIndex].a]) {
      setScore((s) => s + 1);
    } else {
      setGameOver(true);
    }
    if (questionIndex === questionAndAnswers.length - 1) {
      setCompleted(true);
    } else {
      setQuestionIndex(questionIndex + 1);
    }
  };

  const display5050 = () => {
    if (!fiftyFiftyUsed && questionIndex === 0) {
      setFiftyFiftyUsed(true);
    }
  };

  const useLifeline = () => {
    if (lifelineCount > 0 && !lifelineUsed) {
      setLifelineCount(lifelineCount - 1);
      setLifelineUsed(true); // Hoca'ya sorma hakkını kullandık
    }
  };

  // Her yeni soruya geçildiğinde lifelineUsed durumunu sıfırla
  useEffect(() => {
    setLifelineUsed(false);
  }, [questionIndex]);

  if (gameOver) {
    return (
      <p>
        Yanlış cevap seçtiniz, Oyun bitti! Ödülünüz{" "}
        {Math.floor(prizeAmounts[questionIndex])} TL<br /> <br />
        <button onClick={restart}>Yeniden Başlat</button>
      </p>
    );
  }

  if (completed) {
    return (
      <p>
        {Math.floor(prizeAmounts[questionIndex])} TL <br /> kazandınız.
        Artık bir Milyoner oldunuz
        <br /> <br />
        <button onClick={restart}>Yeniden Başlat</button>
      </p>
    );
  }

  const currentQuestion = questionAndAnswers[questionIndex];
  const options = fiftyFiftyUsed && questionIndex === 0 
    ? [currentQuestion.o[currentQuestion.a], currentQuestion.o.filter((_, index) => index !== currentQuestion.a)[Math.floor(Math.random() * (currentQuestion.o.length - 1))]] 
    : currentQuestion.o;

  return (
    <div className="app-container">
      <h1 style={{ fontSize: "5vw" }}>Kim Filozof Olmak İster!!!</h1>

      <div className="game-container">
        <div className="question-container">
          <div className="lifeline">
            <button onClick={useLifeline} disabled ={lifelineCount === 0 || lifelineUsed}>
              Sınıfa Sorma ({lifelineCount} hakkınız var)
            </button>
            <button disabled={fiftyFiftyUsed} onClick={display5050} style={{ opacity: fiftyFiftyUsed ? 0.5 : 1 }}>
              50-50
            </button>
          </div>
          <h2>
            Soru {questionIndex + 1} / {questionAndAnswers.length}
          </h2>
          <Question
            question={currentQuestion.q}
            options={options}
            onSelect={handleSelect}
          />
        </div>

        <div className="prize-table">
          <h2>Ödül Miktarları</h2>
          <ul>
            {prizeAmounts.map((amount, index) => (
              <li key={index} className={index === questionIndex ? "highlight" : ""}>
                {amount} TL
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}

export default App;